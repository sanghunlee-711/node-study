저를 writem3.txt로 보내주세요
파이핑을 시작하자
